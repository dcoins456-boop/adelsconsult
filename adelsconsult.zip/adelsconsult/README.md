# Adels Consult Landing Page

This is a static one-page website prepared for Adels Consult.

## Main Files

- `index.html` contains the full landing page layout based on the provided PNG mockup.
- `styles.css` contains the brand styling using `#0504AA`, `#EDC531`, `#000000`, and `#FFFFFF`.
- `script.js` handles smooth scrolling for the navigation links and the home section carousel.
- `success.html` is the thank-you page shown after a successful quote request.
- `assets/images/` contains the logo, page images, and carousel images.
- `assets/icons/` contains the service and footer icons.

